// search.js — AI search page logic

const MOCK_RESOURCES = [
  // Articles
  { type: 'article', title: 'A Gentle Introduction to Machine Learning', source: 'Towards Data Science', desc: 'A comprehensive beginner-friendly overview of core ML concepts, supervised vs unsupervised learning, and real-world applications.', level: 'Beginner', rating: 4.8, url: '#' },
  { type: 'article', title: 'The Math Behind Neural Networks Explained', source: 'MIT OpenCourseWare', desc: 'Covers linear algebra and calculus fundamentals required to truly understand how deep learning models are trained and optimized.', level: 'Intermediate', rating: 4.6, url: '#' },
  { type: 'article', title: 'Overfitting and Regularization in Practice', source: 'Google AI Blog', desc: 'Practical strategies to prevent models from memorizing training data, with code examples in Python using scikit-learn.', level: 'Intermediate', rating: 4.5, url: '#' },
  { type: 'article', title: 'Transformers: Attention is All You Need — Explained', source: 'Distill.pub', desc: 'A visual, interactive breakdown of the landmark 2017 paper that changed NLP, written for readers with basic ML background.', level: 'Advanced', rating: 4.9, url: '#' },
  { type: 'article', title: 'Climate Change and Machine Learning: New Frontiers', source: 'Nature Climate Change', desc: 'Peer-reviewed research on how AI models are being used to simulate climate systems, optimize energy grids, and predict extreme weather.', level: 'Advanced', rating: 4.7, url: '#' },

  // Videos
  { type: 'video', title: '3Blue1Brown: Neural Networks Series', source: 'YouTube', desc: 'The gold standard visual introduction to neural networks. Stunning animations make backpropagation and gradient descent intuitive.', level: 'Beginner', rating: 4.9, url: '#' },
  { type: 'video', title: 'Stanford CS229: Machine Learning Full Lecture Series', source: 'Stanford Online', desc: 'Andrew Ng\'s legendary ML course, recorded at Stanford. Covers regression, classification, SVMs, clustering, and reinforcement learning.', level: 'Intermediate', rating: 4.8, url: '#' },
  { type: 'video', title: 'Quantum Computing for Computer Scientists', source: 'Microsoft Research', desc: 'A rigorous but accessible primer on quantum bits, entanglement, and quantum gates — no physics PhD required.', level: 'Intermediate', rating: 4.6, url: '#' },
  { type: 'video', title: 'The Climate Crisis: A Data Science Perspective', source: 'TED-Ed', desc: 'How data scientists and climate researchers collaborate to model global warming scenarios and evaluate policy interventions.', level: 'Beginner', rating: 4.7, url: '#' },

  // Tutorials
  { type: 'tutorial', title: 'Build Your First Neural Network with PyTorch', source: 'PyTorch Docs', desc: 'Step-by-step tutorial: define a model, write a training loop, and evaluate performance on the MNIST handwritten digit dataset.', level: 'Beginner', rating: 4.7, url: '#' },
  { type: 'tutorial', title: 'Text Classification with Hugging Face Transformers', source: 'Hugging Face', desc: 'Fine-tune a pre-trained BERT model for sentiment analysis in under 30 minutes using Python and the datasets library.', level: 'Intermediate', rating: 4.8, url: '#' },
  { type: 'tutorial', title: 'Implementing a Sorting Algorithm Visualizer', source: 'GeeksforGeeks', desc: 'Code bubble sort, merge sort, and quicksort from scratch in JavaScript, with a step-by-step animated visualization canvas.', level: 'Beginner', rating: 4.5, url: '#' },
  { type: 'tutorial', title: 'Graph Algorithms Deep Dive: Dijkstra to A*', source: 'AlgoExpert', desc: 'Implement pathfinding algorithms with real-world applications in maps and game AI. Includes complexity analysis and edge cases.', level: 'Advanced', rating: 4.6, url: '#' },

  // Courses
  { type: 'course', title: 'Deep Learning Specialization', source: 'Coursera / deeplearning.ai', desc: 'Five-course specialization by Andrew Ng covering deep learning, CNNs, sequence models, and ML strategy. Widely regarded as the best structured ML curriculum.', level: 'Intermediate', rating: 4.9, url: '#' },
  { type: 'course', title: 'Introduction to Computer Science and Programming', source: 'edX / MIT', desc: 'MIT\'s legendary 6.00.1x course. Covers Python fundamentals, computational thinking, recursion, and algorithmic complexity.', level: 'Beginner', rating: 4.8, url: '#' },
  { type: 'course', title: 'Data Science: R Basics', source: 'HarvardX', desc: 'Harvard\'s introduction to R for data analysis, covering data wrangling, visualization, and statistical inference with real datasets.', level: 'Beginner', rating: 4.6, url: '#' },
  { type: 'course', title: 'Advanced NLP with spaCy', source: 'spaCy + Explosion AI', desc: 'Free interactive course covering named entity recognition, text classification, dependency parsing, and training custom pipelines.', level: 'Advanced', rating: 4.7, url: '#' },
];

const TYPE_ICONS = {
  article: '📄',
  video: '▶',
  tutorial: '⌨',
  course: '🎓',
};

let currentResults = [];
let sortMode = 'relevance';
let activeFilters = {
  types: new Set(['article', 'video', 'tutorial', 'course']),
  levels: new Set(['Beginner', 'Intermediate', 'Advanced']),
  minRating: 1,
};

const LOADING_MESSAGES = [
  'Analyzing your query with NLP...',
  'Searching trusted educational sources...',
  'Ranking resources by relevance...',
  'Almost there — curating results...',
];

// On page load
window.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const query = params.get('q');
  const stage = params.get('stage') || 'researching';

  const navInput = document.getElementById('nav-search-input');
  const navStage = document.getElementById('nav-stage-select');
  if (query && navInput) navInput.value = query;
  if (stage && navStage) navStage.value = stage;

  if (query) {
    simulateSearch(query, stage);
  }

  // Sync filter checkboxes
  syncFilterCheckboxes();
});

function syncFilterCheckboxes() {
  const checkboxes = document.querySelectorAll('.filter-check input[type=checkbox]');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', applyFilters);
  });
}

function simulateSearch(query, stage) {
  const loadingEl = document.getElementById('loading-state');
  const emptyEl = document.getElementById('empty-state');
  const gridEl = document.getElementById('results-grid');
  const metaEl = document.getElementById('results-meta');
  const labelEl = document.getElementById('loading-label');

  emptyEl.style.display = 'none';
  gridEl.innerHTML = '';
  loadingEl.style.display = 'flex';

  let step = 0;
  const msgInterval = setInterval(() => {
    if (labelEl && step < LOADING_MESSAGES.length) {
      labelEl.textContent = LOADING_MESSAGES[step++];
    }
  }, 600);

  setTimeout(() => {
    clearInterval(msgInterval);
    loadingEl.style.display = 'none';

    // Filter results by keyword match (simple simulation)
    const keywords = query.toLowerCase().split(/\s+/).filter(k => k.length > 2);
    let scored = MOCK_RESOURCES.map(r => {
      const haystack = `${r.title} ${r.desc} ${r.source}`.toLowerCase();
      const score = keywords.reduce((acc, kw) => acc + (haystack.includes(kw) ? 2 : 0), 0);
      return { ...r, score: score + Math.random() * 0.8 };
    });

    // Stage weighting
    if (stage === 'brainstorming') {
      scored = scored.map(r => ({ ...r, score: r.score + (r.type === 'video' ? 1.5 : 0) + (r.level === 'Beginner' ? 1 : 0) }));
    } else if (stage === 'wrapping') {
      scored = scored.map(r => ({ ...r, score: r.score + (r.type === 'article' ? 1.5 : 0) + (r.level === 'Advanced' ? 1 : 0) }));
    }

    currentResults = scored.sort((a, b) => b.score - a.score);

    if (metaEl) {
      const stageLabel = { brainstorming: '💡 Brainstorming', researching: '🔍 Researching', wrapping: '🎯 Wrapping Up' }[stage] || stage;
      metaEl.textContent = `${currentResults.length} results for "${query}" · Stage: ${stageLabel}`;
    }

    renderResults(currentResults);
  }, 2400);
}

function renderResults(results) {
  const gridEl = document.getElementById('results-grid');
  const emptyEl = document.getElementById('empty-state');
  if (!gridEl) return;

  // Apply filters
  const checkboxes = document.querySelectorAll('.filter-check input[type=checkbox]');
  const typeFilters = new Set();
  const levelFilters = new Set();
  let minRating = 1;

  checkboxes.forEach(cb => {
    const label = cb.closest('label')?.textContent?.trim();
    if (!cb.checked) return;
    if (['Articles','Videos','Tutorials','Courses'].includes(label)) {
      typeFilters.add(label.slice(0, -1).toLowerCase()); // strip s
    }
    if (['Beginner','Intermediate','Advanced'].includes(label)) {
      levelFilters.add(label);
    }
  });

  const ratingSlider = document.querySelector('.rating-slider');
  if (ratingSlider) minRating = parseFloat(ratingSlider.value);

  // Also map 'Tutorials' -> 'tutorial', 'Articles' -> 'article'
  const typeMap = { articles: 'article', videos: 'video', tutorials: 'tutorial', courses: 'course' };
  const normTypes = new Set([...typeFilters].map(t => typeMap[t] || t));

  let filtered = results.filter(r => {
    if (normTypes.size && !normTypes.has(r.type)) return false;
    if (levelFilters.size && !levelFilters.has(r.level)) return false;
    if (r.rating < minRating) return false;
    return true;
  });

  // Sort
  if (sortMode === 'rating') filtered.sort((a, b) => b.rating - a.rating);
  else if (sortMode === 'newest') filtered.sort(() => Math.random() - 0.5);

  if (!filtered.length) {
    emptyEl.style.display = 'flex';
    gridEl.innerHTML = '';
    return;
  }

  emptyEl.style.display = 'none';
  gridEl.innerHTML = filtered.map((r, i) => `
    <div class="result-card type-${r.type}" style="animation-delay:${i * 0.05}s">
      <div class="rc-type-badge">
        <div class="rc-type-icon">${TYPE_ICONS[r.type]}</div>
        <span class="rc-type-label">${r.type}</span>
      </div>
      <div class="rc-body">
        <div class="rc-meta">
          <span class="rc-source">${r.source}</span>
          <span class="rc-dot">•</span>
          <span class="rc-level level-${r.level}">${r.level}</span>
        </div>
        <div class="rc-title">${r.title}</div>
        <div class="rc-desc">${r.desc}</div>
      </div>
      <div class="rc-actions">
        <div class="rc-rating">
          <span class="rc-stars">★</span>
          <span class="rc-score">${r.rating.toFixed(1)}</span>
        </div>
        <a href="${r.url}" class="rc-visit" target="_blank" rel="noopener">View →</a>
      </div>
    </div>
  `).join('');
}

function applyFilters() {
  if (currentResults.length) renderResults(currentResults);
}

function sortResults(mode) {
  sortMode = mode;
  if (currentResults.length) renderResults(currentResults);
}

function updateRatingLabel(slider) {
  const label = document.getElementById('rating-label');
  if (label) {
    label.textContent = slider.value > 1 ? `${slider.value}+ stars` : 'Any rating';
  }
}

function quickSearch(query) {
  const navInput = document.getElementById('nav-search-input');
  if (navInput) navInput.value = query;
  const params = new URLSearchParams({ q: query, stage: 'researching' });
  history.pushState({}, '', `?${params.toString()}`);
  simulateSearch(query, 'researching');
  const metaEl = document.getElementById('results-meta');
  if (metaEl) metaEl.textContent = `Searching for "${query}"...`;
}
