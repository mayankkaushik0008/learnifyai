# LearnifyAI — AI-Based Learning Resource Finder

A responsive multi-page website + Flask backend for an AI-powered educational resource discovery platform.

---

## Project Structure

```
learnifyai/
├── index.html       # Landing page (Hero, Mission, How It Works, Features, Audience, CTA)
├── search.html      # Search results page with filters + AI loading animation
├── style.css        # Full responsive CSS (dark navy + teal theme)
├── main.js          # Navbar, scroll effects, hero search handler
├── search.js        # Search simulation, result rendering, filters
├── app.py           # Flask API backend
└── README.md
```

---

## Frontend — Open Directly in Browser

No build step needed. Just open `index.html` in any modern browser.

```bash
# macOS / Linux
open index.html

# Windows
start index.html

# Or serve with Python for local development:
python -m http.server 8080
# Then visit http://localhost:8080
```

---

## Backend — Flask API

### Install dependencies

```bash
pip install flask flask-cors
```

### Run the server

```bash
python app.py
```

API will be available at `http://localhost:5000`

---

## API Reference

### `GET /api/search`

Search for learning resources using AI-like scoring.

**Parameters:**
| Parameter    | Type   | Default       | Description                              |
|--------------|--------|---------------|------------------------------------------|
| `q`          | string | (required)    | Search query / topic                     |
| `stage`      | string | `researching` | Project stage: `brainstorming`, `researching`, `wrapping` |
| `type`       | string | (all)         | Filter by: `article`, `video`, `tutorial`, `course` |
| `level`      | string | (all)         | Filter by: `Beginner`, `Intermediate`, `Advanced` |
| `sort`       | string | `relevance`   | Sort by: `relevance` or `rating`         |
| `min_rating` | float  | `1.0`         | Minimum rating threshold (1.0–5.0)       |
| `limit`      | int    | `10`          | Max results to return                    |

**Example:**
```
GET /api/search?q=machine+learning&stage=brainstorming&type=video&level=Beginner
```

**Response:**
```json
{
  "query": "machine learning",
  "stage": "brainstorming",
  "total": 2,
  "results": [
    {
      "id": 2,
      "type": "video",
      "title": "3Blue1Brown: Neural Networks Series",
      "source": "YouTube",
      "level": "Beginner",
      "rating": 4.9,
      "url": "https://youtube.com",
      "tags": ["neural networks", "deep learning", "visual"],
      "desc": "Stunning animations make backpropagation and gradient descent intuitive.",
      "_score": 5.234
    }
  ]
}
```

### `GET /api/resource/<id>`
Get a single resource by ID.

### `GET /api/suggestions`
Get popular search topic suggestions for the UI.

### `GET /api/health`
Health check — returns `{"status": "ok"}`.

---

## Design System

| Token        | Value        | Usage                       |
|--------------|--------------|-----------------------------|
| `--navy`     | `#0D1B2A`    | Page background             |
| `--navy-mid` | `#162032`    | Section alternates          |
| `--navy-card`| `#1A2840`    | Cards & inputs              |
| `--teal`     | `#00D4B4`    | Primary accent, CTAs        |
| `--sky`      | `#4FB8FF`    | Secondary accent            |
| `--muted`    | `#8A9BB5`    | Body text, placeholders     |
| Font (heading)| DM Serif Display | Serif display font      |
| Font (body)  | DM Sans      | Clean sans-serif            |

---

## Connecting Frontend to Flask API

The frontend currently uses mock data for demo purposes. To connect to the real Flask API, update `search.js`:

```js
// Replace simulateSearch() with a real fetch call:
async function fetchFromAPI(query, stage) {
  const res = await fetch(`http://localhost:5000/api/search?q=${encodeURIComponent(query)}&stage=${stage}`);
  const data = await res.json();
  return data.results;
}
```

---

## Future Enhancements (from business plan)

- 🌐 Integrate real educational APIs: Coursera, Khan Academy, arXiv, YouTube Data API
- 📱 Mobile app (React Native)
- 🌍 Multi-language support
- 🤖 Real NLP via spaCy or HuggingFace
- 📊 User dashboard with learning history
- 🎓 Institution admin panel
