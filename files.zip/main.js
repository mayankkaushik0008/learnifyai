// main.js — Landing page interactions

// Navbar scroll behavior
const navbar = document.getElementById('navbar');
if (navbar) {
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) navbar.classList.add('scrolled');
    else navbar.classList.remove('scrolled');
  });
}

// Mobile menu
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });
}

// Fill hero search from chips
function fillSearch(text) {
  const input = document.getElementById('hero-search');
  if (input) {
    input.value = text;
    input.focus();
  }
}

// Handle hero search form submit
function handleSearch(e) {
  e.preventDefault();
  const heroInput = document.getElementById('hero-search');
  const navInput = document.getElementById('nav-search-input');
  const stageEl = document.getElementById('project-stage') || document.getElementById('nav-stage-select');

  const query = (heroInput || navInput)?.value?.trim();
  const stage = stageEl?.value || 'researching';

  if (!query) return;

  const params = new URLSearchParams({ q: query, stage });
  window.location.href = `search.html?${params.toString()}`;
}

// Scroll reveal — simple intersection observer
const revealTargets = document.querySelectorAll(
  '.mission-card, .how-step, .feature-card, .audience-card'
);
if (revealTargets.length) {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        entry.target.style.animationDelay = `${i * 0.06}s`;
        entry.target.style.animation = 'fadeUp 0.5s ease both';
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  revealTargets.forEach(el => obs.observe(el));
}
