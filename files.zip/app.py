"""
LearnifyAI — Flask Backend
Run: pip install flask flask-cors && python app.py
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import time
import random

app = Flask(__name__)
CORS(app)

# ── Mock resource database ────────────────────────────────────────────────────

RESOURCES = [
    {"id": 1, "type": "article", "title": "A Gentle Introduction to Machine Learning",
     "source": "Towards Data Science", "level": "Beginner", "rating": 4.8,
     "url": "https://towardsdatascience.com", "tags": ["machine learning", "AI", "intro"],
     "desc": "A comprehensive beginner-friendly overview of core ML concepts."},

    {"id": 2, "type": "video", "title": "3Blue1Brown: Neural Networks Series",
     "source": "YouTube", "level": "Beginner", "rating": 4.9,
     "url": "https://youtube.com", "tags": ["neural networks", "deep learning", "visual"],
     "desc": "Stunning animations make backpropagation and gradient descent intuitive."},

    {"id": 3, "type": "tutorial", "title": "Build Your First Neural Network with PyTorch",
     "source": "PyTorch Docs", "level": "Beginner", "rating": 4.7,
     "url": "https://pytorch.org", "tags": ["pytorch", "deep learning", "python", "tutorial"],
     "desc": "Step-by-step guide: train a model on the MNIST dataset."},

    {"id": 4, "type": "course", "title": "Deep Learning Specialization",
     "source": "Coursera / deeplearning.ai", "level": "Intermediate", "rating": 4.9,
     "url": "https://coursera.org", "tags": ["deep learning", "CNNs", "sequence models"],
     "desc": "Five-course specialization by Andrew Ng — the definitive ML curriculum."},

    {"id": 5, "type": "article", "title": "Climate Change and Machine Learning",
     "source": "Nature Climate Change", "level": "Advanced", "rating": 4.7,
     "url": "https://nature.com", "tags": ["climate", "AI", "environment", "research"],
     "desc": "How AI models are being used to simulate climate systems."},

    {"id": 6, "type": "video", "title": "Stanford CS229: Machine Learning Lectures",
     "source": "Stanford Online", "level": "Intermediate", "rating": 4.8,
     "url": "https://online.stanford.edu", "tags": ["stanford", "machine learning", "lecture"],
     "desc": "Andrew Ng's legendary Stanford ML course, fully recorded."},

    {"id": 7, "type": "tutorial", "title": "Text Classification with Hugging Face",
     "source": "Hugging Face", "level": "Intermediate", "rating": 4.8,
     "url": "https://huggingface.co", "tags": ["NLP", "transformers", "BERT", "python"],
     "desc": "Fine-tune a pre-trained BERT model for sentiment analysis."},

    {"id": 8, "type": "article", "title": "Transformers: Attention is All You Need — Explained",
     "source": "Distill.pub", "level": "Advanced", "rating": 4.9,
     "url": "https://distill.pub", "tags": ["transformers", "NLP", "attention", "research"],
     "desc": "A visual breakdown of the landmark paper that changed NLP."},

    {"id": 9, "type": "course", "title": "Introduction to CS and Programming (MIT 6.00.1x)",
     "source": "edX / MIT", "level": "Beginner", "rating": 4.8,
     "url": "https://edx.org", "tags": ["python", "programming", "CS", "beginner"],
     "desc": "MIT's legendary intro CS course — covers Python and algorithmic thinking."},

    {"id": 10, "type": "video", "title": "Quantum Computing for Computer Scientists",
     "source": "Microsoft Research", "level": "Intermediate", "rating": 4.6,
     "url": "https://research.microsoft.com", "tags": ["quantum", "computing", "qubits"],
     "desc": "A rigorous but accessible primer on quantum computing."},
]


# ── Simple NLP keyword scorer (no external libs needed) ───────────────────────

def score_resource(resource, keywords, stage):
    """Score a resource by keyword match + stage relevance."""
    haystack = f"{resource['title']} {resource['desc']} {' '.join(resource['tags'])}".lower()
    score = sum(2 for kw in keywords if kw in haystack)

    # Stage weighting
    if stage == "brainstorming":
        if resource["type"] == "video": score += 1.5
        if resource["level"] == "Beginner": score += 1.0
    elif stage == "wrapping":
        if resource["type"] == "article": score += 1.5
        if resource["level"] == "Advanced": score += 1.0
    elif stage == "researching":
        if resource["type"] in ("article", "tutorial"): score += 0.5

    # Add small random noise to avoid ties
    score += random.uniform(0, 0.5)
    return score


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def home():
    return jsonify({
        "app": "LearnifyAI API",
        "version": "1.0.0",
        "endpoints": {
            "GET /api/search?q=<query>&stage=<stage>&type=<type>&level=<level>": "Search resources",
            "GET /api/resource/<id>": "Get single resource",
            "GET /api/health": "Health check",
        }
    })


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "timestamp": time.time()})


@app.route("/api/search")
def search():
    query = request.args.get("q", "").strip().lower()
    stage = request.args.get("stage", "researching")
    resource_type = request.args.get("type", "")       # article|video|tutorial|course
    level = request.args.get("level", "")              # Beginner|Intermediate|Advanced
    sort_by = request.args.get("sort", "relevance")    # relevance|rating
    min_rating = float(request.args.get("min_rating", 1.0))
    limit = int(request.args.get("limit", 10))

    if not query:
        return jsonify({"error": "Query parameter 'q' is required"}), 400

    # Tokenize query (rudimentary NLP)
    keywords = [w for w in query.split() if len(w) > 2]

    # Filter & score
    results = []
    for r in RESOURCES:
        if resource_type and r["type"] != resource_type:
            continue
        if level and r["level"] != level:
            continue
        if r["rating"] < min_rating:
            continue
        score = score_resource(r, keywords, stage)
        results.append({**r, "_score": round(score, 3)})

    # Sort
    if sort_by == "rating":
        results.sort(key=lambda x: x["rating"], reverse=True)
    else:
        results.sort(key=lambda x: x["_score"], reverse=True)

    results = results[:limit]

    return jsonify({
        "query": query,
        "stage": stage,
        "total": len(results),
        "results": results,
    })


@app.route("/api/resource/<int:resource_id>")
def get_resource(resource_id):
    resource = next((r for r in RESOURCES if r["id"] == resource_id), None)
    if not resource:
        return jsonify({"error": "Resource not found"}), 404
    return jsonify(resource)


@app.route("/api/suggestions")
def suggestions():
    """Return popular search topics for the UI."""
    topics = [
        "Machine Learning basics",
        "Climate Change solutions",
        "Quantum Computing",
        "Data Structures and Algorithms",
        "Natural Language Processing",
        "Computer Vision",
        "World War 2 causes",
        "Photosynthesis biology",
        "Python programming",
        "Statistics for Data Science",
    ]
    return jsonify({"suggestions": topics})


# ── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("🚀 LearnifyAI Flask API starting at http://localhost:5000")
    print("   Frontend: open index.html in a browser")
    print("   API docs: http://localhost:5000/")
    app.run(debug=True, port=5000)
